﻿using LoggerLibrary.Appenders.Contracts;
using LoggerLibrary.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace LoggerLibrary.Appenders.Factory.Contracts
{
    public interface IAppenderFactory
    {
        IAppender CreateAppender(string type, ILayout layout);


    }
}
