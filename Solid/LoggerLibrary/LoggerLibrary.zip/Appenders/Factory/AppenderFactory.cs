﻿using LoggerLibrary.Appenders.Contracts;
using LoggerLibrary.Appenders.Factory.Contracts;
using LoggerLibrary.Contracts;
using LoggerLibrary.Loggers;
using System;
using System.Collections.Generic;
using System.Text;

namespace LoggerLibrary.Appenders.Factory
{
    public class AppenderFactory : IAppenderFactory
    {

        public IAppender CreateAppender(string type, ILayout layout)
        {
            string typeToLower = type.ToLower();

            switch (typeToLower)
            {
                case "consoleappender":
                    return new ConsoleAppender(layout);

                case "fileappender":
                    return new FileAppender(layout, new LogFile());

                default:
                    throw new ArgumentException("Invalid appender type!");
            }
        }
    }
}
