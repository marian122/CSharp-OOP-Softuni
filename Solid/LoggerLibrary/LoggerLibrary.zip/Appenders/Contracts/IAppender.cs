﻿using LoggerLibrary.Loggers.Enum;
using System;
using System.Collections.Generic;
using System.Text;

namespace LoggerLibrary.Appenders.Contracts
{
    public interface IAppender
    {
        int MessagesCount { get; }

        ReportLevel ReportLevel { get; set; }

        void Append(string dateTime, ReportLevel reportLevel, string message);
    }
}
