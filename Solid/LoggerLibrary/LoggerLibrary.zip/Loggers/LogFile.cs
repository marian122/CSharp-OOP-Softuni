﻿using LoggerLibrary.Appenders.Contracts;
using LoggerLibrary.LoggerClass.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LoggerLibrary.Loggers
{
    public class LogFile : ILogFile
    {
       
        public int Size { get; private set; }

        public void Write(string message)
        {
            this.Size += message.Where(char.IsLetter).Sum(s => s);
        }
    }
}
