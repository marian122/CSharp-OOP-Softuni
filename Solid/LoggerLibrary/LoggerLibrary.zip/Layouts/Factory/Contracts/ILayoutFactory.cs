﻿using LoggerLibrary.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace LoggerLibrary.Layouts.Factory.Contracts
{
    public interface ILayoutFactory
    {
        ILayout CreateLayout(string type);
    }
}
