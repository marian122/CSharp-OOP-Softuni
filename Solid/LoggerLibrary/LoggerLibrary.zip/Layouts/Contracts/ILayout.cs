﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LoggerLibrary.Contracts
{
    public interface ILayout
    {
        string Format { get; }
    }
}
