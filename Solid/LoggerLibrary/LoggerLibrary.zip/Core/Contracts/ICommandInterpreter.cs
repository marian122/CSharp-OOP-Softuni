﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LoggerLibrary.Core.Contracts
{
    public interface ICommandInterpreter
    {
        void AddAppender(string[] input);

        void AddMessage(string[] input);

        void PrintInfo();
    }
}
