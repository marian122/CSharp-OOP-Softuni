﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LoggerLibrary.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
