﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Problem5.BorderControl
{
    public interface IIDentify
    {
        string Id { get; }
    }
}
