﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Problem6.BirthdayCelebrations
{
    public interface IIDentify
    {
        string Birthdate { get; }
    }
}
