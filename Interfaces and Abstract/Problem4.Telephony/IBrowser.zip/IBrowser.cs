﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Problem4.Telephony
{
    public interface IBrowser
    {
        string Browse(string url);
    }
}
