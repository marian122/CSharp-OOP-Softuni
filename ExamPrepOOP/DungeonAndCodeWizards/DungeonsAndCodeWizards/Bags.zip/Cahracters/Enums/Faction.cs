﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DungeonsAndCodeWizards.Cahracters.Enums 
{
    public enum Faction
    {
        CSharp,
        Java
    }
}
