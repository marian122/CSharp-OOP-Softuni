﻿namespace Databasee
{
    using System;

    public class StartUp
    {
        public static void Main()
        {
            
            Database db = new Database(1, 2, 3, 4, 5, 6, 7, 8);
        }
    }
}
